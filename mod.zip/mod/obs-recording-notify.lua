-- ============================================
-- OBS 录屏启停弹窗提醒插件
-- 开始/停止录制时弹出提醒（由 notify.exe 显示，含声音）
-- 安装：工具 → 脚本 → "+" → 选择本文件
-- ============================================
obs = obslua

-- 脚本所在目录（mod 文件夹），把正斜杠转成 Windows 反斜杠
local MOD_DIR = script_path():gsub("/", "\\")
if not MOD_DIR:match("[\\/]$") then
	MOD_DIR = MOD_DIR .. "\\"
end

-- 写信号文件通知常驻进程弹窗（不启动外部程序，无黑窗）
local function signal(action)
	local f = io.open(MOD_DIR .. "signal.txt", "w")
	if f then
		f:write(action)
		f:close()
	end
end

-- 监听前端事件（用 STARTING/STOPPING，点击录制瞬间就触发）
local function on_event(event)
	if event == obs.OBS_FRONTEND_EVENT_RECORDING_STARTING then
		signal("start")
	elseif event == obs.OBS_FRONTEND_EVENT_RECORDING_STOPPING then
		signal("stop")
	end
end

function script_load(settings)
	obs.obs_frontend_add_event_callback(on_event)
	-- 启动常驻监控进程
	os.execute('start "" /b "' .. MOD_DIR .. 'notify.exe" --watch')
end

function script_unload()
	-- 通知常驻进程退出
	local f = io.open(MOD_DIR .. "signal.txt", "w")
	if f then
		f:write("exit")
		f:close()
	end
end
